public class A {
   
   public void m(){
      System.out.println("A");
   }
   
   public A(){
      m();
   }
}