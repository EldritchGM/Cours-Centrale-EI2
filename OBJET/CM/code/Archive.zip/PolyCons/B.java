public class B extends A {
   private int b;
   public B() {
      b = 1;
   }
   
   public void m() {
      System.out.println("b vaut "+b);
   }
}