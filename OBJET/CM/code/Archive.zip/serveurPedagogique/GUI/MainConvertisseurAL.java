public class MainConvertisseurAL {
   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) {
      // on la rend visible
      ConvertisseurTempAL conv = new ConvertisseurTempAL();
      conv.showGUI();
   }

}