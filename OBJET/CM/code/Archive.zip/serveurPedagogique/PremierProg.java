public class PremierProg {
   
   // Cette fonction represente le programme principal
   // elle equivaut a la fonction main() de C/C++
   public static void main(String[] args)
   {
      // cet appel equivaut au std::cout de C++
      System.out.println("Hello World!");
   }
   
}