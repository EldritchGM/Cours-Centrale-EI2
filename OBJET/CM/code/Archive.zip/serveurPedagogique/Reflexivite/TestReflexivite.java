import java.util.ArrayList;
import java.util.List;

public class TestReflexivite {
   
   public static boolean estInstanceDe(Object o, String nomClasse) {
      System.out.println("Je teste si on est de la classe: "+nomClasse);
      System.out.println("La clase de l'objet est: "+o.getClass().getName());
      boolean result = nomClasse.equals(o.getClass().getName());
      return result;
   }
   
   public static final void main(String[] args) {
      {columns}
   }
   
}