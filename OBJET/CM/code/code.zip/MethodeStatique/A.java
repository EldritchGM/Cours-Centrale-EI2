public class A {
   public static void methodeStatique() {
      System.out.println("Méthode statique");
   }
   
   public void methodeClassique() {
      System.out.println("Méthode classique");
   }
}