public class ExemplePolymorphismeConstructeur {

   public static void main(String[] args) {
      B bb = new B();
   }
}