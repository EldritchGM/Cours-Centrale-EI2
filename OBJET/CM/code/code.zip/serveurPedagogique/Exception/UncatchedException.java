class UncatchedException {
	public static void main(String[] args) {
		int[] tab = new int[18];
		// on fait volotairement une b�tise
		System.out.println(tab[18]);
	}
}


